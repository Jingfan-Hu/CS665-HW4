package cs665.Hw4.JFHu;
/**
* Name: Jingfan Hu
* Course: CS-665 Software Designs & Patterns
* Date: 11/07/2023
* File Name: Main.java
* Description: Junit tests
*/
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.Test;

public class CustomerDataAdapterTest {

    @Test
    public void testPrintCustomer() {
        // Create a mock Legacy System
        CustomerData_USB legacySystem = mock(CustomerData_USB.class);

        // Create an adapter
        CustomerDataAdapter adapter = new CustomerDataAdapter(legacySystem);

        // Define the behavior of the legacy system's printCustomer method
        when(legacySystem.printCustomer(123)).thenReturn("Printing customer data for ID 123");

        // Test printCustomer method in the adapter
        String result = adapter.printCustomer(123);

        // Verify that the printCustomer method from the legacy system is called
        verify(legacySystem).printCustomer(123);

        // Assert the result
        assertEquals("Printing customer data for ID 123", result);
    }

    @Test
    public void testGetCustomer_HTTPS() {
        // Create a mock Legacy System
        CustomerData_USB legacySystem = mock(CustomerData_USB.class);

        // Create an adapter
        CustomerDataAdapter adapter = new CustomerDataAdapter(legacySystem);

        // Define the behavior of the legacy system's getCustomer_USB method
        when(legacySystem.getCustomer_USB(456)).thenReturn("Retrieving customer data via USB for ID 456");

        // Test getCustomer_HTTPS method in the adapter
        String result = adapter.getCustomer_HTTPS(456);

        // Verify that the getCustomer_USB method from the legacy system is called
        verify(legacySystem).getCustomer_USB(456);

        // Assert the result
        assertEquals("Retrieving customer data via USB for ID 456", result);
    }

    @Test
    public void testCombinedFunctionality() {
        // Create a mock Legacy System
        CustomerData_USB legacySystem = mock(CustomerData_USB.class);

        // Create an adapter
        CustomerDataAdapter adapter = new CustomerDataAdapter(legacySystem);

        // Define the behavior of the legacy system's methods
        when(legacySystem.getCustomer_USB(789)).thenReturn("Retrieving customer data via USB for ID 789");
        when(legacySystem.printCustomer(111)).thenReturn("Printing customer data for ID 111");

        // Test combined functionality
        String printResult = adapter.printCustomer(111);
        String retrieveResult = adapter.getCustomer_HTTPS(789);

        // Verify that the methods from the legacy system are called
        verify(legacySystem).printCustomer(111);
        verify(legacySystem).getCustomer_USB(789);

        // Assert the results
        assertEquals("Printing customer data for ID 111", printResult);
        assertEquals("Retrieving customer data via USB for ID 789", retrieveResult);
    }
}
