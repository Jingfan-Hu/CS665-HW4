package cs665.Hw4.JFHu;
/**
* Name: Jingfan Hu
* Course: CS-665 Software Designs & Patterns
* Date: 11/07/2023
* File Name: Main.java
* Description: The CustomerDataAdapter class acts as an adapter, enabling the integration of the legacy 
* system's interface with the new system's interface, facilitating customer data printing and retrieval 
* operations and allowing for additional logic if necessary.
*/
//Adapter to make the Legacy System work with the New System's interface
public class CustomerDataAdapter implements CustomerData_HTTPS {
 private final CustomerData_USB legacySystem;

 public CustomerDataAdapter(CustomerData_USB legacySystem) {
     this.legacySystem = legacySystem;
 }

 public void printCustomer(int customerId) {
     // Delegate the printCustomer operation to the legacy system
     legacySystem.printCustomer(customerId);
 }

 public void getCustomer_HTTPS(int customerId) {
     // Implement the getCustomer_HTTPS method using the legacy system
     legacySystem.getCustomer_USB(customerId);
     // Additional logic for processing data through the new system can be added here if needed.
 }
}
