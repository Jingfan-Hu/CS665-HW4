package cs665.Hw4.JFHu;

/**
* Name: Jingfan Hu
* Course: CS-665 Software Designs & Patterns
* Date: 11/07/2023
* File Name: Main.java
* Description: Legacy system Interface
*/

public interface CustomerData_USB {
    void printCustomer(int customerId);
    void getCustomer_USB(int customerId);
}
