package cs665.Hw4.JFHu;
/**
* Name: Jingfan Hu
* Course: CS-665 Software Designs & Patterns
* Date: 11/07/2023
* File Name: Main.java
* Description: The LegacySystem class implements the CustomerData_USB interface, 
* facilitating the printing and retrieval of customer data via a USB connection 
* and binary files, serving as part of the integration of legacy systems into a 
* new interface.
*/
//Concrete implementation of the Legacy System
public class LegacySystem implements CustomerData_USB {
 public void printCustomer(int customerId) {
     // Implementation for printing customer data from the USB connection
     System.out.println("Printing customer data for ID " + customerId);
 }

 public void getCustomer_USB(int customerId) {
     // Implementation for retrieving customer data from USB and binary files
     System.out.println("Retrieving customer data via USB for ID " + customerId);
 }
}